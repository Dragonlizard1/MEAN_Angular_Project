import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';





@Injectable()
export class HttpService {
	 constructor(private _http: HttpClient) {
	    this.getPokemon();
	}

	getPokemon(){
	    let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
		let ability1 = this._http.get('https://pokeapi.co/api/v2/ability/65/');
		bulbasaur.subscribe(data => console.log("Got our tasks pokemon!", data));

		ability1.subscribe(data => {
			console.log("Got our tasks ability!", data);
			console.log("Pokemon List shared same ability: overgrow");
			for (let index = 0; index < data.pokemon.length; index++)
			{

				console.log("Poekmon Name: ", data.pokemon[index].pokemon.name);
			}


		});  // subscribe end


	} //getPokemon end
}; //Export class end




  //  constructor(private _http: HttpClient){
  //   	 this.getTasks();
  //   	};

  //   getTasks(){
  //   // our http response is an Observable, store it in a variable
  //   let tempObservable = this._http.get('/tasks');
  //   // subscribe to the Observable and provide the code we would like to do with our data from the response
  //   tempObservable.subscribe(data => console.log("Got our tasks!", data));
 	// };
