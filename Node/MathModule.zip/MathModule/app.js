var my_module = require('./mathlib')();


console.log(my_module.add(2,3),  "add");


console.log(my_module.multiply(3,5),  "multiply");

console.log(my_module.square(5),  "square");

console.log(my_module.random(1,35),  "random1");

console.log(my_module.random(1,35),  "random2");

console.log(my_module.random(1,35),  "random1");

console.log(my_module.random(1,35),  "random2");




